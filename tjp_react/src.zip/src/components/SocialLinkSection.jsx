// import React, { useEffect, useState } from 'react'

// const SocialLinkSection = () => {
//   const [linkedProviders, setLinkedProviders] = useState([]);
//   const [isProcessing, setIsProcessing] = useState(false);
//   const supportedProviders = [
//       { id: 'google', name: 'Google', icon: '🟢' },
//       { id: 'kakao', name: 'Kakao', icon: '🟡' },
//       // 추가 프로바이더들...
//   ];

//   useEffect(() => {
//         fetchLinkedProviders();
//     }, []);
//   return (
//     <div>
      
//     </div>
//   )
// }

// export default SocialLinkSection

import React from 'react'
import { createSlice } from '@reduxjs/toolkit'

const initialState = {
    isAuthenticated: false,
    user: null,
    warning : null,
    accessToken : null,
}

const authSlice = createSlice({
    name: 'auth',
    initialState,
    reducers: {
        login(state, action) {
            state.isAuthenticated = true
            state.user = action.payload
        },
        logout(state) {
            state.isAuthenticated = false
            state.user = null
            state.accessToken = null
            state.warning= null
        },
        setWarning: (state, action) => {
            state.warning = action.payload
        },
        clearWarning: (state) => {
            state.warning = null
        },
        setAccessToken(state, action) {
            state.accessToken = action.payload
        },
        clearAccessToken(state) {
            state.accessToken = null
        }
    }
}) 

export const { login, logout, setWarning, clearWarning, setAccessToken, clearAccessToken } = authSlice.actions
export default authSlice.reducer
